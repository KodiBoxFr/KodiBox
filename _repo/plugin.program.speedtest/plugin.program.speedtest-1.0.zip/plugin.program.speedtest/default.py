from libs import speedtest

url = 'http://speedtest.ftp.otenet.gr/files/test10Mb.db'

speedtest.runfulltest(url)
