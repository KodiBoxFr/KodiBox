import os, xbmc, xbmcgui, xbmcaddon

addon = xbmcaddon.Addon()
addon_id = addon.getAddonInfo('id')

AddonTitle = addon.getAddonInfo('name')

path = addon.getAddonInfo('path')