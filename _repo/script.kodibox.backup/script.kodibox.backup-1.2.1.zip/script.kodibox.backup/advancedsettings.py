import os, shutil, sys
import backup
from libs import kodi

def replaceSettings():
    src_file = os.path.join(kodi.userdata_path, kodi.file_name)
    
    # Read in the file
    with open(src_file, 'r') as file :
        filedata = file.read()

    # Replace the target string
    filedata = filedata.replace('settings>', 'advancedsettings>')

    # Write the file out again
    with open(src_file, 'w') as file:
        file.write(filedata)

    backup.full_backup()

def deleteSettings():
    for the_file in os.listdir(kodi.backup):
        file_path = os.path.join(kodi.backup, the_file)
        try:
            if os.path.isfile(file_path):
                os.unlink(file_path)
        except Exception as e:
            print(e)
            
    replaceSettings()

def copySettings():
    src_file = os.path.join(kodi.backup, kodi.file_name)
    shutil.copy(src_file,kodi.userdata_path)

    deleteSettings()

def moveSettings(old_file_name, new_file_name):
    if not os.path.exists(kodi.backup):
        os.makedirs(kodi.backup)
        
    src_file = os.path.join(kodi.userdata_path, old_file_name)
    shutil.copy(src_file,kodi.backup)

    dst_file = os.path.join(kodi.backup, old_file_name)
    new_dst_file_name = os.path.join(kodi.backup, new_file_name)
    os.rename(dst_file, new_dst_file_name)

    copySettings()

def chkSettings():
    src_file = os.path.join(kodi.userdata_path, kodi.file_name)
    if not os.path.exists(src_file):
        moveSettings("guisettings.xml","advancedsettings.xml")
    else:
        os.remove(src_file)
        moveSettings("guisettings.xml","advancedsettings.xml")