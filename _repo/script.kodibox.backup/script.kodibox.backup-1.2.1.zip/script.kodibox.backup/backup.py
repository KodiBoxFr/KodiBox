import shutil
import time
import urllib
import zipfile
import traceback

import os
import sys
import xbmc
import xbmcaddon
import xbmcgui
import chkVersion
from libs import kodi

dp = xbmcgui.DialogProgress()
dialog = xbmcgui.Dialog()

# #############  Backup  ############################################

def full_backup():
    exclude_dirs = ['backupdir', 'cache', 'temp', 'packages', 'script.kodibox.update', 'script.kodibox.backup', 'Thumbnails', 'service.xbmc.wooppay']
    exclude_files = ["spmc.log", "spmc.old.log", "xbmc.log", "xbmc.old.log", "kodi.log", "kodi.old.log", "fretelly.log",
                     "freetelly.old.log", "guisettings.xml", "favourites.xml"]
    message_header = "%s Is Creating A  Full  Backup..." % kodi.AddonTitle
    message1 = "Archiving..."
    message2 = ""
    message3 = ""
    archive_cb(kodi.home_path, message_header, message1, message2, message3, exclude_dirs, exclude_files)

def archive_cb(sourcefile, message_header, message1, message2, message3, exclude_dirs, exclude_files):
    destfile = xbmc.translatePath(os.path.join(kodi.zip_path, kodi.build_name))
    zipobj = zipfile.ZipFile(destfile, 'w', zipfile.ZIP_DEFLATED)
    rootlen = len(sourcefile)
    for_progress = []
    item = []
    dp.create(message_header, message1, message2, message3)

    for base, dirs, files in os.walk(sourcefile):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        files[:] = [f for f in files if f not in exclude_files]        
        for n_file in files:
            item.append(n_file)

    n_item = len(item)
    
    for base, dirs, files in os.walk(sourcefile):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        files[:] = [f for f in files if f not in exclude_files]
        for file_n in files:
            try:
                for_progress.append(file_n)
                progress = len(for_progress) / float(n_item) * 100
                dp.update(int(progress), "Archiving..", '[COLOR blue]%s[/COLOR]' % file_n, '')
                fp = os.path.join(base, file_n)
                zipobj.write(fp, fp[rootlen:])
            except Exception, e:
                kodi.log(str(e))
    zipobj.close()
    dp.close()
    time.sleep(1)

    chkVersion.changeVersion()