import os, xbmc, xbmcgui, xbmcaddon, ftplib, time

addon = xbmcaddon.Addon()
addon_id = addon.getAddonInfo('id')

AddonTitle = addon.getAddonInfo('name')

file_name = "advancedsettings.xml"
old_file_name = "guisettings.xml"

selfAddon = xbmcaddon.Addon(id=addon_id)

path = addon.getAddonInfo('path')

backupfull = selfAddon.getSetting('backup_database')
backupaddons = selfAddon.getSetting('backup_addon_data')
zip_path = os.path.join(addon.getAddonInfo('path') , "backup")

home_path = xbmc.translatePath(os.path.join('special://home', ''))
addons_path = xbmc.translatePath(os.path.join('special://home', 'addons', ''))
userdata_path = xbmc.translatePath(os.path.join('special://home', 'userdata', ''))
packages_path = xbmc.translatePath(os.path.join('special://home', 'addons', 'packages'))
addon_data_path = xbmc.translatePath(os.path.join(userdata_path, 'addon_data'))
databases_path = xbmc.translatePath(os.path.join(userdata_path, 'Database'))
excludes_folder = xbmc.translatePath(os.path.join(userdata_path, 'BACKUP'))

backup = os.path.join(addon.getAddonInfo('path') , "backup")

version = os.path.join(addon.getAddonInfo('path'), 'version')
update_img = os.path.join(addon.getAddonInfo('path'), 'icon.png')

timestr = time.strftime("%Y%m%d")

build_name = 'new_build.zip'
build_new_name = 'build.zip'
build_old_name = 'build_'+timestr+'.zip'
version_name = 'version'

# session = ftplib.FTP('217.182.80.23','www-data','Myaraf2128jessica2128')

# version_url = "http://217.182.80.23/_Kodi_usb/version"

def get_setting(id):
    return addon.getSetting(id)
     
def set_setting(id, value):
    addon.setSetting(id, value)

def message(text1, text2="", text3=""):
    if text3 == "":
        xbmcgui.Dialog().ok(text1, text2)
    elif text2 == "":
        xbmcgui.Dialog().ok("", text1)
    else:
        xbmcgui.Dialog().ok(text1, text2, text3)

def log(msg, level=xbmc.LOGNOTICE):
    name = str('KodiBox') + ' NOTICE'
    # override message level to force logging when addon logging turned on
    level = xbmc.LOGNOTICE

    try:
        xbmc.log('%s: %s' % (name, msg), level)
    except:
        try:
            xbmc.log('Logging Failure', level)
        except:
            pass  # just give up