import ftplib
import os
import xbmc
import xbmcgui
import chkVersion
import sys
from libs import kodi

count = 0
blockSize = 1024

dialog = xbmcgui.Dialog()
dp = xbmcgui.DialogProgress()

ftp = kodi.get_setting('ftp')
session = ftplib.FTP(ftp)

def callback(p):
	global count, blocksize, file_name
	src_file = xbmc.translatePath(os.path.join(kodi.zip_path, file_name))
	totalSize = int(os.stat(src_file).st_size)
	count += 1
	if totalSize > 0:
		try:
			percent = int(count * blockSize * 100 / totalSize)
			dp.update(percent)
		except:
			percent = 100
			dp.update(percent)
		if dp.iscanceled():
			dp.close()

def upload():
	global file_name
	dp.create("KodiBox Backup","Upload to ftp in progress...",' ', ' ')
	dp.update(0)

	ftp_user = kodi.get_setting('ftpUser')
	ftp_password = kodi.get_setting('ftpPassword')
	ftp_path = kodi.get_setting('ftpPath')

	session.login(ftp_user, ftp_password)

	file_name = kodi.build_name
	build_file = xbmc.translatePath(os.path.join(kodi.zip_path, file_name))
	fp = open(build_file, 'rb')
	session.storbinary('STOR ' + ftp_path + file_name, fp, 1024, callback)
	session.cwd(ftp_path)
	session.sendcmd('site chmod 775 ' + file_name)
	session.cwd('/.')

	file_name = kodi.version_name
	version_file = xbmc.translatePath(os.path.join(kodi.zip_path, file_name))
	fp = open(version_file, 'rb')
	session.storbinary('STOR ' + ftp_path + file_name, fp)
	session.cwd(ftp_path)
	session.sendcmd('site chmod 775 ' + file_name)
	session.cwd('/.')

	dp.close()
	session.cwd(ftp_path)

	if  kodi.build_new_name in session.nlst():
		session.rename(kodi.build_new_name, kodi.build_old_name)
		session.rename(kodi.build_name, kodi.build_new_name)
	else:
		session.rename(kodi.build_name, kodi.build_new_name)

	session.close()
	os.remove(build_file)

	src_file = os.path.join(kodi.userdata_path, kodi.file_name)
	os.remove(src_file)

	dialog.ok('KodiBox Backup', 'Full backup done & Upload on FTP complete')