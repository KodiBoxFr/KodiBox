import xbmc, xbmcgui, os
import advancedsettings
from libs import kodi

dlg = xbmcgui.Dialog()

def showDialog():
	osName = kodi.get_setting('os')
	response = dlg.yesno('KodiBox Backup','Do you want to make a backup ?', yeslabel='Yes', nolabel='No')
	if response:
		backup.full_backup()
	else:
		xbmc.executebuiltin("XBMC.ActivateWindow(Home)")

def getOS_type():
	osName = kodi.get_setting('os')
	if osName == '':
		src_file = '/etc/os-release'
		if os.path.exists(src_file):
			file = open(src_file, 'r')
			getOS = file.readlines()
			osName = getOS[0].strip()
			osName = osName.replace('NAME=', '')
			osName = osName.replace('"', '')
			version = getOS[3].strip()
			version = version.replace('VERSION_ID=', '')
			version = version.replace('"', '')
			
			if osName == 'OpenELEC':
				kodi.set_setting('os', 'OpenELEC')
				if version == '7.0':
					ftp_path = kodi.get_setting('orangepiUrl')
					kodi.set_setting('ftpPath', ftp_path)
				else:
					ftp_path = kodi.get_setting('raspberrypiUrl')
					kodi.set_setting('ftpPath', ftp_path)
			else:
				kodi.set_setting('os', 'LibreELEC')
				ftp_path = kodi.get_setting('orangepiUrl')
				kodi.set_setting('ftpPath', ftp_path)

	showDialog()

if __name__ == '__main__':
	getOS_type()