import ftplib, os, io, xbmc, xbmcgui, urllib
import uploadFTP, time
from libs import kodi

def changeVersion():
	destfile = xbmc.translatePath(os.path.join(kodi.zip_path, kodi.version_name))
	version = time.strftime("%Y%m%d")
	with io.FileIO(destfile, "w") as file:
		file.write('VERSION='+str(version))
	xbmc.sleep(4000)
	destfile = xbmc.translatePath(os.path.join(kodi.update_path, kodi.version_name))
	os.remove(destfile)
	with io.FileIO(destfile, "w") as file:
		file.write('VERSION='+str(version))
	uploadFTP.upload()