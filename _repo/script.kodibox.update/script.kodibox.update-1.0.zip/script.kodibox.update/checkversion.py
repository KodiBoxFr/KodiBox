import os, io,sys, urllib
import xbmc, xbmcgui, xbmcaddon
import downloader
import extract
from libs import kodi

AddonTitle = kodi.addon.getAddonInfo('name')
build_zip = os.path.join(kodi.packages_path, 'build.zip')

dialog = xbmcgui.Dialog()

def restart_kodi():
	dialog.notification('INSTALLING UPDATE', 'Nearly finished...', kodi.update_img, 6000, False)	
	xbmc.sleep(4000)
	dialog.ok(AddonTitle, "Installation Complete.", "", "Click OK to exit Kodi and then restart to complete .")
	xbmc.executebuiltin('ShutDown')

def change_version():
	os.remove(kodi.version)
	new_version = open(kodi.new_version)
	new_version = new_version.read()
	os.remove(kodi.new_version)
	xbmc.sleep(4000)
	with io.FileIO(kodi.version, "w") as file:
		file.write('VERSION='+new_version)
	xbmc.sleep(4000)
	restart_kodi()

def extract_build():
	dp = xbmcgui.DialogProgress()
	try:
		dp.create(AddonTitle, 'Getting ' + AddonTitle + ' Ready........', 'Extracting KodiBox Addons & Config......')
		dp.update(0)
		#extract.all(build_zip, kodi.addons_path, dp)
		extract.all(build_zip, kodi.home_path, dp)
		dp.close()
		change_version()
	except:
		pass

def get_build():
	dp = xbmcgui.DialogProgress()
	try:
		dp.create(AddonTitle, 'Getting ' + AddonTitle + ' Ready........', 'Downloading KodiBox Addons & Config......')
		dp.update(0)
		downloader.download(kodi.build_url, build_zip, dp)
		dp.close()
		xbmc.sleep(4000)
		extract_build()
	except:
		pass

def check_version(url):
	old_version = open(kodi.version)
	old_version = old_version.read()
	old_version = old_version.replace('VERSION=', '')
	new_version = urllib.urlopen(url).read()
	new_version = new_version.replace('VERSION=', '')
	if (new_version > old_version):
		dialog.notification('NEW UPDATE AVAILABLE', 'in progress...', kodi.update_img, 6000, False)	
		xbmc.sleep(4000)
		with io.FileIO(kodi.new_version, "w") as file:
			file.write(new_version)	
		get_build()
	else:
		dialog.notification('NO UPDATE AVAILABLE', 'You are fully up to date!', kodi.update_img, 6000, False)	