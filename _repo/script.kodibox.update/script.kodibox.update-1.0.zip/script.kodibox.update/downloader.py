import xbmc, xbmcgui
import os
import urllib2
import socket
import extract
from libs import kodi
import time

packages_path = xbmc.translatePath(os.path.join('special://home', 'addons', 'packages'))
build = os.path.join(packages_path, 'build.zip')

def download(url, dest, dp = None,timeout = None):
    if timeout == None:
        timeout = 1200000

    try:
        if not dp:
            dp = xbmcgui.DialogProgress()
            dp.create("KodiBox","New Update Download in progress...",' ', ' ')
        dp.update(0)
        start_time = time.time()
        u = urllib2.urlopen(url, timeout = timeout)
        h = u.info()
        totalSize = int(h["Content-Length"])
        fp = open(dest, 'wb')
        blockSize = 8192 #100000 # urllib.urlretrieve uses 8192
        count = 0
        while True:  # and (end - start < 15):
            if time.time() - start_time > timeout:
                kodi.message("Slow or no Download available:", 'Files could not be downloaded at this time',
                             'Please try again later, Attempting to continue...')
                break
            chunk = u.read(blockSize)
            if not chunk: break
            fp.write(chunk)
            count += 1
            if totalSize > 0:
                try:
                    percent = int(count * blockSize * 100 / totalSize)
                    dp.update(percent)
                except:
                    percent = 100
                    dp.update(percent)
                if dp.iscanceled():
                    dp.close()
                    raise Exception("Canceled")
        timetaken =  time.time() - start_time
        kodi.log('Duration of download was %.02f secs ' % timetaken )
    except socket.timeout, e:
        # For Python 2.7
        kodi.message("There was an error: %r" % e, 'Files could not be downloaded at this time', 'Please try again later, Attempting to continue...')
        return
    except urllib2.HTTPError as e:
        kodi.message("There was an error:", str(e),'Please try again later, Attempting to continue...')
        return