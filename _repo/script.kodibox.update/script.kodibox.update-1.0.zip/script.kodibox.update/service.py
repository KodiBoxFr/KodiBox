import xbmc, xbmcgui, xbmcaddon
import checkversion
from libs import kodi

xbmcgui.Dialog().notification('CHECK SYSTEM', 'System is Update.', kodi.update_img, 6000, False)
xbmc.sleep(4000)
checkversion.check_version(kodi.version_url)

