import os, io,sys, urllib
import xbmc, xbmcgui, xbmcaddon
import downloader
import extract
import urllib2
from libs import kodi

dialog = xbmcgui.Dialog()

def restart_kodi():
	dialog.ok(kodi.AddonTitle, "Installation Complete.", "", "Kodi restart to complete update.")
	xbmc.restart()

def change_version():
	os.remove(kodi.version)
	new_version = open(kodi.new_version)
	new_version = new_version.read()
	os.remove(kodi.new_version)
	xbmc.sleep(4000)
	with io.FileIO(kodi.version, "w") as file:
		file.write('VERSION='+new_version)
	xbmc.sleep(4000)
	restart_kodi()

def extract_build():
	dp = xbmcgui.DialogProgress()
	try:
		dp.create(kodi.AddonTitle, 'Getting ' + kodi.AddonTitle + ' Ready........', 'Extracting KodiBox Addons & Config......')
		dp.update(0)
		extract.all(kodi.build, kodi.home_path, dp)
		dp.close()
		change_version()
	except:
		pass

def get_build():
	dp = xbmcgui.DialogProgress()
	try:
		dp.create(kodi.AddonTitle, 'Getting ' + kodi.AddonTitle + ' Ready........', 'Downloading KodiBox Addons & Config......')
		dp.update(0)
		build_url = kodi.get_setting('buildUrl')
		downloader.download(build_url, kodi.build, dp)
		xbmc.sleep(4000)
		extract_build()
	except:
		pass

def check_version(url):
	old_version = open(kodi.version)
	old_version = old_version.read()
	old_version = old_version.replace('VERSION=', '')

	new_version = urllib.urlopen(url).read()
	new_version = new_version.replace('VERSION=', '')
	if (new_version > old_version):
		dialog.notification('NEW UPDATE AVAILABLE', 'in progress...', xbmcgui.NOTIFICATION_INFO, 6000, True)
		xbmc.sleep(4000)
		with io.FileIO(kodi.new_version, "w") as file:
			file.write(new_version)	
		get_build()
	else:
		dialog.notification('NO UPDATE AVAILABLE', 'You are fully up to date!', xbmcgui.NOTIFICATION_INFO, 6000, True)	

def checkUrl(url):
	try:
		urllib2.urlopen(url)
		return True
	except urllib2.HTTPError, e:
		return False

def getOS_type():
	osName = kodi.get_setting('os')
	if osName == '':
		src_file = '/etc/os-release'
		if os.path.exists(src_file):
			file = open(src_file, 'r')
			getOS = file.readlines()
			osName = getOS[0].strip()
			osName = osName.replace('NAME=', '')
			osName = osName.replace('"', '')
			version = getOS[3].strip()
			version = version.replace('VERSION_ID=', '')
			version = version.replace('"', '')			
			
			if osName == 'OpenELEC':
				kodi.set_setting('os', osName)
				if version == '7.0':
					ftp = 'http://' + kodi.get_setting('ftp')
					ftp_path = kodi.get_setting('orangepiUrl')
				else:
					ftp = 'http://' + kodi.get_setting('ftp')
					ftp_path = kodi.get_setting('raspberrypiUrl')
			else:
				kodi.set_setting('os', 'LibreELEC')
				ftp = 'http://' + kodi.get_setting('ftp')
				ftp_path = kodi.get_setting('orangepiUrl')
				
			version_url = ftp + ftp_path + kodi.version_name
			kodi.set_setting('versionUrl', version_url)
			build_url = ftp + ftp_path + kodi.build_name
			kodi.set_setting('buildUrl', build_url)

	version_url = kodi.get_setting('versionUrl')
	version = checkUrl(version_url)

	if version == True:
		check_version(version_url)
	else:
		dialog.notification('NO UPDATE AVAILABLE', 'You are fully up to date!', xbmcgui.NOTIFICATION_INFO, 6000, True)	