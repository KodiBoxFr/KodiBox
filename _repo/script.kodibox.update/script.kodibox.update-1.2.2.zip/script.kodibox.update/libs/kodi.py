import os, xbmc, xbmcgui, xbmcaddon

addon = xbmcaddon.Addon()
addon_id = addon.getAddonInfo('id')

AddonTitle = addon.getAddonInfo('name')

path = addon.getAddonInfo('path')
home_path = xbmc.translatePath(os.path.join('special://home', ''))
addons_path = xbmc.translatePath(os.path.join('special://home', 'addons', ''))
userdata_path = xbmc.translatePath(os.path.join('special://home', 'userdata', ''))
packages_path = xbmc.translatePath(os.path.join('special://home', 'addons', 'packages'))

version = os.path.join(addon.getAddonInfo('path'), 'version')
new_version = os.path.join(addon.getAddonInfo('path'), 'new_version')
update_img = os.path.join(addon.getAddonInfo('path'), 'icon.png')

build_url = "http://217.182.80.23/_Kodi_usb/build.zip"
version_url = "http://217.182.80.23/_Kodi_usb/version"

# build =  os.path.join(addon.getAddonInfo('path'), 'build.zip')
build = os.path.join(packages_path, 'build.zip')

build_name = 'build.zip'
version_name = "version"

def get_setting(id):
    return addon.getSetting(id)
     
def set_setting(id, value):
    addon.setSetting(id, value)

def message(text1, text2="", text3=""):
    if text3 == "":
        xbmcgui.Dialog().ok(text1, text2)
    elif text2 == "":
        xbmcgui.Dialog().ok("", text1)
    else:
        xbmcgui.Dialog().ok(text1, text2, text3)

def log(msg, level=xbmc.LOGNOTICE):
    name = str('KodiBox') + ' NOTICE'
    # override message level to force logging when addon logging turned on
    level = xbmc.LOGNOTICE

    try:
        xbmc.log('%s: %s' % (name, msg), level)
    except:
        try:
            xbmc.log('Logging Failure', level)
        except:
            pass  # just give up