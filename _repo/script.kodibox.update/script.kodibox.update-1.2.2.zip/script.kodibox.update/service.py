import xbmc, xbmcgui, xbmcaddon
import checkversion
from libs import kodi

dialog = xbmcgui.Dialog()

if __name__ == '__main__':
	os_name = kodi.get_setting('os')
	if os_name == '':
		checkversion.getOS_type()
	else:
		version_url = kodi.get_setting('versionUrl')
		version = checkversion.checkUrl(version_url)

		if version == True:
			checkversion.check_version(version_url)
		else:
			xbmc.sleep(4000)
			dialog.notification('NO UPDATE AVAILABLE', 'You are fully up to date!', kodi.update_img, 6000, False)	